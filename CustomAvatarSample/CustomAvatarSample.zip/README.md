# ZEP Script Animation Object Sample

<br>

![sample](https://i.imgur.com/YuzQQPo.gif)

<br>

He is walking.
